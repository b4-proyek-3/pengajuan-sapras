@extends('layout.main')
@section('content')
<!-- cards -->
<div class="w-full px-6 md:px-6 py-6 mx-auto">
  <h5 class="font-bold text-lg mb-4">Detail Pengajuan</h5>
    <!-- cards row 1 -->
  <div class="flex flex-wrap -mx-3">
    <div class="max-w-full px-3 lg:w-2/3 lg:flex-none">
      <div class="flex flex-wrap -mx-3">

        <!-- card 1 -->
        <div class="max-w-full px-3 mb-4 lg:mb-0 lg:w-full lg:flex-none">
          <div class="border-black/12.5 shadow-soft-xl relative flex min-w-0 flex-col break-words rounded-2xl border-0 border-solid bg-white bg-clip-border">
            <div class="border-black/12.5 mb-0 rounded-t-2xl border-b-0 border-solid bg-white p-6 pb-0">
              <div class="flex flex-wrap mt-0 -mx-3">
                <div class="flex-none w-7/12 max-w-full px-3 mt-0 lg:w-1/2 lg:flex-none">
                  <h6>Pengajuan</h6>
                  <p class="mb-0 text-sm leading-normal">
                  <i class="fa fa-calendar text-cyan-500"></i>
                    <span class="ml-1 font-semibold">No Pengajuan #</span>
                    {{ $pengajuans->id_pengajuan ?? 'N/A' }}
                  </p>
                </div>
                <div class="flex-none w-1/12 max-w-full px-3 my-auto text-right lg:w-1/2 lg:flex-none">
                  <div class="relative pr-6 lg:float-right">
                  @if ($pengajuans->status == 'direvisi')
                    <a dropdown-trigger class="cursor-pointer" aria-expanded="false" onclick="openPengajuanModal()">
                      <i class="fa fa-pencil"></i>
                    </a>
                  @endif
                  </div>
                </div>
              </div>
            </div>
            <div class="flex-auto p-6 px-0 pb-2">
              <div class="overflow-x-auto">
                <table class="items-center w-full mb-0 align-top border-gray-200 text-slate-500">
                  <td class="p-0 align-middle bg-transparent border-b whitespace-nowrap">
                  <td class="p-0 align-middle bg-transparent border-b whitespace-nowrap">
                  <td class="p-0 align-middle bg-transparent border-b whitespace-nowrap">
                  <td class="p-0 align-middle bg-transparent border-b whitespace-nowrap">
                  <tbody>
                  <tr>
                      <td class="p-2 align-middle bg-transparent whitespace-nowrap">
                          <div class="flex px-4 py-1">
                              <div class="flex flex-col justify-center" style="min-width: 150px;">
                                  <h6 class="mb-0 text-sm leading-normal">Nama Pengaju</h6>
                              </div>
                              <div class="flex flex-col justify-center" style="min-width: 10px; text-align: right;">
                                  <h6 class="mb-0 text-sm leading-normal">:</h6>
                              </div>
                              <div class="flex flex-col justify-center pl-2">
                                  <h6 class="mb-0 text-sm leading-normal">{{ $pengajuans->nama_ketuplak ?? 'N/A' }}</h6>
                              </div>
                          </div>
                      </td>
                  </tr>
                  <tr>
                      <td class="p-2 align-middle bg-transparent whitespace-nowrap">
                          <div class="flex px-4 py-1">
                              <div class="flex flex-col justify-center" style="min-width: 150px;">
                                  <h6 class="mb-0 text-sm leading-normal">Nomor Telepon</h6>
                              </div>
                              <div class="flex flex-col justify-center" style="min-width: 10px; text-align: right;">
                                  <h6 class="mb-0 text-sm leading-normal">:</h6>
                              </div>
                              <div class="flex flex-col justify-center pl-2">
                                  <h6 class="mb-0 text-sm leading-normal">{{ $pengajuans->notelp ?? 'N/A' }}</h6>
                              </div>
                          </div>
                      </td>
                  </tr>
                  <tr>
                      <td class="p-2 align-middle bg-transparent whitespace-nowrap">
                          <div class="flex px-4 py-1">
                              <div class="flex flex-col justify-center" style="min-width: 150px;">
                                  <h6 class="mb-0 text-sm leading-normal">Ormawa</h6>
                              </div>
                              <div class="flex flex-col justify-center" style="min-width: 10px; text-align: right;">
                                  <h6 class="mb-0 text-sm leading-normal">:</h6>
                              </div>
                              <div class="flex flex-col justify-center pl-2">
                                  <h6 class="mb-0 text-sm leading-normal">{{ $pengajuans->pengaju->ormawa->nama_ormawa ?? 'N/A' }}</h6>
                              </div>
                          </div>
                      </td>
                  </tr>
                  <tr>
                      <td class="p-2 align-middle bg-transparent whitespace-nowrap">
                          <div class="flex px-4 py-1">
                              <div class="flex flex-col justify-center" style="min-width: 150px;">
                                  <h6 class="mb-0 text-sm leading-normal">Jenis Kegiatan</h6>
                              </div>
                              <div class="flex flex-col justify-center" style="min-width: 10px; text-align: right;">
                                  <h6 class="mb-0 text-sm leading-normal">:</h6>
                              </div>
                              <div class="flex flex-col justify-center pl-2">
                                  <h6 class="mb-0 text-sm leading-normal">{{ str_replace('proker', 'Program Kerja', ucfirst($pengajuans->jenis_kegiatan) ?? 'N/A') }}</h6>
                              </div>
                          </div>
                      </td>
                  </tr>
                  <tr>
                      <td class="p-2 align-middle bg-transparent whitespace-nowrap">
                          <div class="flex px-4 py-1">
                              <div class="flex flex-col justify-center" style="min-width: 150px;">
                                  <h6 class="mb-0 text-sm leading-normal">Nama Kegiatan</h6>
                              </div>
                              <div class="flex flex-col justify-center" style="min-width: 10px; text-align: right;">
                                  <h6 class="mb-0 text-sm leading-normal">:</h6>
                              </div>
                              <div class="flex flex-col justify-center pl-2">
                                  <h6 class="mb-0 text-sm leading-normal">{{ $pengajuans->nama_kegiatan ?? 'N/A' }}</h6>
                              </div>
                          </div>
                      </td>
                  </tr>
                  <tr>
                      <td class="p-2 align-middle bg-transparent whitespace-nowrap">
                          <div class="flex px-4 py-1">
                              <div class="flex flex-col justify-center" style="min-width: 150px;">
                                  <h6 class="mb-0 text-sm leading-normal">Jumlah Peserta</h6>
                              </div>
                              <div class="flex flex-col justify-center" style="min-width: 10px; text-align: right;">
                                  <h6 class="mb-0 text-sm leading-normal">:</h6>
                              </div>
                              <div class="flex flex-col justify-center pl-2">
                                  <h6 class="mb-0 text-sm leading-normal">{{ $pengajuans->jumlah_peserta ?? 'N/A' }}</h6>
                              </div>
                          </div>
                      </td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div class="max-w-full px-3 mb-4 lg:mb-0 lg:w-full lg:flex-none">
          <div class="border-black/12.5 shadow-soft-xl relative flex min-w-0 flex-col break-words rounded-2xl border-0 border-solid bg-white bg-clip-border">
            <div class="flex-auto p-2 px-0">
              <div class="overflow-x-auto">
                <table class="items-center w-full mb-0">
                  <thead>
                    <tr>
                      <th class="px-6 py-3 text-left align-middle border-b">
                        <h6>Tempat</h6>
                      </th>
                      <th class="px-6 py-3 text-left align-middle border-b">
                        <h6>Tanggal</h6>
                      </th>
                      <th class="px-6 py-3 text-left align-middle border-b">
                        <h6>Waktu</h6>
                      </th>
                      <th class="px-6 py-3 text-left align-middle border-b">
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach ($pengajuans->ruangan as $ruangan)
                    <tr>
                      <td class="p-2 align-middle bg-transparent border-b whitespace-nowrap">
                        <div class="flex px-3 py-1">
                          <div class="flex flex-col justify-center">
                            <h6 class="mb-0 leading-normal text-sm">{{ $ruangan->nama_ruangan ?? 'N/A' }}, {{ $ruangan->gedung->nama_gedung ?? 'N/A'}}</h6>
                          </div>
                        </div>
                      </td>
                      <td class="p-2 align-middle bg-transparent border-b whitespace-nowrap">
                        <div class="flex px-3 py-1">
                          <div class="flex flex-col justify-center">
                            <h6 class="mb-0 leading-normal text-sm">{{ $ruangan->pivot->tanggal_mulai ?? 'N/A' }} - {{ $ruangan->pivot->tanggal_akhir ?? 'N/A'}}</h6>
                          </div>
                        </div>
                      </td>
                      <td class="p-2 leading-normal text-center align-middle bg-transparent border-b text-sm whitespace-nowrap">
                        <div class="flex px-3 py-1">
                          <div class="flex flex-col justify-center">
                            <h6 class="mb-0 leading-normal text-sm">{{ $ruangan->pivot->waktu_mulai ?? 'N/A' }} - {{ $ruangan->pivot->waktu_akhir ?? 'N/A'}}</h6>
                          </div>
                        </div>
                      </td>
                      <td class="p-2 align-middle bg-transparent border-b whitespace-nowrap">
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <div class="w-full max-w-full px-3 lg:w-1/3 lg:flex-none">
      <div class="relative flex flex-col h-full min-w-0 break-words bg-white border-0 border-transparent border-solid shadow-soft-xl rounded-2xl bg-clip-border">
        <div class="border-black/12.5 mb-0 rounded-t-2xl border-b-0 border-solid bg-white p-6 pb-0">
          <h6>Status Pengajuan</h6>
          <p class="text-sm leading-normal">
          </p>
        </div>
        <table class="items-center w-full mb-0 align-top border-gray-200 text-slate-500">
            <td class="p-0 align-middle bg-transparent border-b whitespace-nowrap">
        </table>
        <div class="flex-auto p-4">
          <div class="before:border-r-solid relative before:absolute before:top-0 before:left-4 before:h-full before:border-r-2 before:border-r-slate-100 before:content-[''] before:lg:-ml-px">
            <div class="relative mb-4 mt-0 after:clear-both after:table after:content-['']">
            @if($pengajuans->latestReview->isNotEmpty())
              @foreach ($pengajuans->latestReview as $index => $review)
                  <span class="w-6.5 h-6.5 text-base absolute left-4 z-10 inline-flex -translate-x-1/2 items-center justify-center rounded-full bg-white text-center font-semibold">
                  <i class="relative z-10 leading-none text-transparent
                    {{ $review->status == 'ditolak' ? 'ni ni-fat-remove bg-gradient-to-tl from-red-600 to-red-400' :
                    ($review->status == 'direvisi' ? 'fa fa-pencil bg-gradient-to-tl from-orange-600 to-yellow-400' : 'ni ni-check-bold bg-gradient-to-tl from-green-600 to-lime-400') }}
                    leading-pro bg-clip-text fill-transparent"></i>
                  </span>
                  <div class="ml-11.252 pt-1.4 lg:max-w-120 relative -top-1.5 w-auto">
                      <h6 class="mb-0 text-sm font-semibold leading-normal text-slate-700">{{ $review->reviewer->role_name ?? 'N/A' }}</h6>
                      <p class="mt-1 mb-0 text-xs font-semibold leading-tight text-slate-400">{{ ucfirst($review->status ?? 'N/A') }}</p>
                      <p class="mt-1 mb-0 text-xs font-semibold leading-tight text-slate-400">{{ $review->tanggal_review ?? 'N/A' }}</p>
                  </div>
              @endforeach
            @endif
            </div>
            <div class="relative mb-4 mt-0 after:clear-both after:table after:content-['']">
                <span class="w-6.5 h-6.5 text-base absolute left-4 z-10 inline-flex -translate-x-1/2 items-center justify-center rounded-full bg-white text-center font-semibold">
                    <i class="relative z-10 leading-none text-transparent ni ni-bell-55 bg-gradient-to-tl from-green-600 to-lime-400
                      leading-pro bg-clip-text fill-transparent"></i>
                </span>
                <div class="ml-11.252 pt-1.4 lg:max-w-120 relative -top-1.5 w-auto">
                    <h6 class="mb-0 text-sm font-semibold leading-normal text-slate-700">Pengajuan Dibuat</h6>
                    <p class="mt-1 mb-0 text-xs font-semibold leading-tight text-slate-400">{{ $pengajuans->tanggal_pengajuan ?? 'N/A' }}</p>
                </div>
            </div>
        </div>
        <div class="flex-none w-1/2 max-w-full px-3 text-right">
              <button onclick="window.location='{{ route('tracking.show', ['id_pengajuan' => $pengajuans->id_pengajuan]) }}'" class="inline-block w-full px-8 py-2 mb-0 font-bold text-center uppercase align-middle transition-all bg-transparent border border-solid rounded-lg shadow-none cursor-pointer leading-pro ease-soft-in text-xs bg-150 active:opacity-85 hover:scale-102 tracking-tight-soft bg-x-25 border-fuchsia-500 text-fuchsia-500 hover:opacity-75">View All</button>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="w-full py-6 mx-auto">
  <!-- cards row 2 -->
  <div class="flex flex-wrap -mx-3">
    <div class="max-w-full px-3 lg:w-1/3 lg:flex-none">
      <div class="flex flex-wrap -mx-3">
        <!-- card 1 -->
        <div class="w-full max-w-full px-3 lg:w-full lg:flex-none">
          <h5 class="font-bold text-lg mb-4">Detail Dokumen</h5>
          <div class="border-black/12.5 shadow-soft-xl relative flex min-w-0 flex-col break-words rounded-2xl border-0 border-solid bg-white bg-clip-border">
            <div class="border-black/12.5 mb-0 rounded-t-2xl border-b-0 border-solid bg-white p-6 pb-0">
              <div class="flex flex-wrap mt-0 -mx-3">
                <div class="flex-none w-7/12 max-w-full px-3 mt-0 lg:w-1/2 lg:flex-none">
                  <h6>Dokumen</h6>
                </div>
                <div class="flex-none w-5/12 max-w-full px-3 my-auto text-right lg:w-1/2 lg:flex-none">
                  <div class="relative pr-6 lg:float-right">
                    @if ($pengajuans->status == 'direvisi')
                      <a dropdown-trigger class="cursor-pointer" aria-expanded="false" onclick="openDokumenModal()">
                        <i class="fa fa-pencil"></i>
                      </a>
                    @endif
                  </div>
                </div>
              </div>
            </div>
            <table class="items-center mb-2 mt-2 align-top border-gray-200 text-slate-500">
              <td class="mb-4 mt-4 align-middle bg-transparent border-b whitespace-nowrap">
              <tbody>
              @foreach ($pengajuans->dokumen as $dokumen)
                  <tr>
                      <td class="p-2 align-middle bg-transparent whitespace-nowrap">
                          <div class="flex px-4 py-1">
                              <div class="flex flex-col justify-center">
                                  <h6 class="mb-0 text-sm leading-normal">
                                  <a href="javascript:void(0);" class="dokumen-link" 
                                    data-file="{{ route('file.show', ['id_pengajuan' => $pengajuans->id_pengajuan, 'filename' => basename($dokumen->path)]) }}">
                                     {{ $dokumen->nama_dokumen ?? 'N/A' }}
                                  </a>
                                  </h6>
                              </div>
                          </div>
                      </td>
                  </tr>
              @endforeach
                    <tr>
                      <td class="p-2 align-middle bg-transparent whitespace-nowrap">
                        <div class="flex px-4 py-1">
                          <div class="flex flex-col justify-center">
                            <!-- Link dokumen untuk Card 1 -->
                            <h6 class="mb-0 text-sm leading-normal">
                            @if (!is_null($pengajuans->link_drive))
                                <a href="{{ $pengajuans->link_drive }}" target="_blank" rel="noopener noreferrer">
                                    Surat Izin Orang Tua
                                </a>
                            @endif
                            </h6>
                          </div>
                        </div>
                      </td>
                    </tr>
              </tbody>
            </table>
          </div>
        </div>
        <!-- card 3 -->
        <div class="w-full max-w-full px-3 lg:w-full lg:flex-none">
          <h5 class="font-bold text-lg mb-4 py-6">Catatan</h5>
          <form>
            <div class="w-full mb-4 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-700 dark:border-gray-600">
                <div class="px-4 py-2 bg-white rounded-b-lg dark:bg-gray-800">
                    <textarea id="editor" rows="8"
                    class="block w-full px-2 mt-2 text-sm text-gray-800 bg-white border-0 dark:bg-gray-800 focus:ring-0 dark:text-white dark:placeholder-gray-400" readonly>{{ $pengajuans->latestReview->first()->catatan ?? '-' }}
                    </textarea>
                </div>
            </div>
          </form>
          @if ($pengajuans->status == 'direvisi')
          <form action="{{ route('pengajuan.submit', $pengajuans->id_pengajuan) }}" method="POST">
              @csrf
              @method('POST')
              <div class="flex justify-end">
                  <button type="submit" name="status" value="diterima" class="mt-2 bg-gradient-to-tl from-blue-600 to-teal-400 px-2.5 text-xs rounded-1.8 py-1.4 inline-block whitespace-nowrap text-center align-baseline font-bold uppercase leading-none text-white">
                      Submit
                  </button>
              </div>
          </form>
          @endif
        </div>
      </div>
    </div>
    <!-- card 2 -->
    <div class="w-full max-w-full lg:w-2/3 lg:flex-none">
      <div class="w-full max-w-full mb-4 lg:w-full lg:flex-none">
        <div class="border-black/12.5 shadow-soft-xl relative flex h-full min-w-0 flex-col break-words rounded-2xl border-0 border-solid bg-white bg-clip-border">
          <div class="flex-auto p-2">
            <div class="before:border-r-solid relative before:absolute before:top-0 before:left-4 before:h-full before:border-r-2 before:border-r-slate-100 before:content-[''] before:lg:-ml-px">
              <iframe id="dokumen-frame" src="{{ $firstDocument ? route('file.show', ['id_pengajuan' => $pengajuans->id_pengajuan, 'filename' => basename($firstDocument->path)]) : '' }}" style="width:100%; height:700px;" frameborder="0"></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="pt-4 w-full bg-transparent">
  <div class="container mx-auto px-6">
    <div class="flex flex-wrap items-center justify-center">
      <div class="w-full max-w-full px-3 mt-0 mb-6 lg:mb-0 lg:w-1/2 text-center">
      <p class="text-center text-sm font-normal text-slate-500">
        Pengajuan Sarana dan Prasarana<br>
        Politeknik Negeri Bandung
      </p>
      </div>
    </div>
  </div>
</footer>

@include('modal.modal_edit_pengajuan')
@include('modal.modal_edit_dokumen')
@if (session('success'))

<script>
    Swal.fire({
    position: "center",
    title: "{{session('success')}}",
    showConfirmButton: false,
    timer: 1500,
    icon: "success"
  });
</script>
@endif

@if (session('error'))
<script>
    Swal.fire({
        position: "center",
        title: "{{ session('error') }}",
        showConfirmButton: false,
        timer: 1500,
        icon: "error"
    });
</script>
@endif

<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Ambil semua elemen dengan class 'dokumen-link'
    const dokumenLinks = document.querySelectorAll('.dokumen-link');

    // Loop melalui setiap link dokumen
    dokumenLinks.forEach(function (link) {
      // Tambahkan event listener 'click'
      link.addEventListener('click', function () {
        // Ambil URL file dari atribut data-file
        const fileUrl = link.getAttribute('data-file');
        
        // Ambil elemen iframe dan ubah src-nya
        const iframe = document.getElementById('dokumen-frame');
        iframe.src = fileUrl;
      });
    });
  });
</script>
@endsection