@extends('layout.login')
@section('content')

<main class="flex items-center justify-center min-h-screen bg-gray-100 p-4 sm:p-6">
    <section class="relative flex flex-col lg:flex-row w-full max-w-4xl h-auto lg:h-[32rem] rounded-3xl overflow-hidden shadow-lg">
        <!-- First Column -->
        <div class="relative lg:w-1/2 w-full h-48 sm:h-64 lg:h-full bg-cover bg-center flex items-center justify-center" 
            style="background-image: url('{{ asset('assets/img/gedung.png') }}');">
            <div class="absolute inset-0 bg-black opacity-30"></div>
            <div class="relative z-10 p-4 sm:p-6 text-center lg:text-left">
                <h1 class="text-lg sm:text-xl lg:text-3xl font-bold text-white">
                    Sistem Informasi Kemahasiswaan Polban
                </h1>
            </div>
        </div>

        <!-- Second Column (Login, Forgot Password, and Reset Password Forms) -->
<div class="w-full lg:w-1/2 flex flex-col p-10 sm:p-6 md:p-8 lg:p-10 bg-white relative min-h-[400px] sm:min-h-[500px] lg:min-h-auto">            <!-- Login Form -->
            <div id="loginForm" class="absolute inset-0 transition-transform duration-700 ease-in-out flex flex-col justify-between p-10 bg-white">
                <div class="title mb-6">
                    <h1 class="text-2xl font-bold">Login</h1>
                </div>
                <form method="POST" action="{{ route('login.submit') }}">
                    @csrf
                    <div class="space-y-5">
                        <div>
                            <label for="email" class="block pb-3 text-sm font-medium text-gray-700">Email</label>
                            <input type="email" name="email" id="email" class="focus:shadow-soft-primary-outline text-sm block w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-700 focus:border-fuchsia-300 focus:outline-none transition-shadow" placeholder="example@polban.ac.id">
                            @error('email')
                                <span class="text-red-500">{{ $message }}</span>
                            @enderror
                        </div>
                        <div>
                            <label for="password" class="block pb-3 text-sm font-medium text-gray-700">Password</label>
                            <input type="password" name="password" id="password" class="focus:shadow-soft-primary-outline text-sm block w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-700 focus:border-fuchsia-300 focus:outline-none transition-shadow" placeholder="********">
                            @error('password')
                                <span class="text-red-500">{{ $message }}</span>
                            @enderror
                            <span class="pt-2 block">Forgot your password? <a href="#" id="forgotPasswordLink" class="text-blue-500"><strong>Click here</strong></a></span>
                        </div>
                    </div>
                    <div class="mt-6">
                        <button type="submit" class="inline-block w-full px-6 py-3 font-bold text-white uppercase transition-all bg-orange-500 hover:bg-orange-700 rounded-lg shadow-md hover:scale-105 hover:shadow-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                            Login
                        </button>
                    </div>
                </form>
            </div>

            <!-- Forgot Password Form -->
            <div id="forgotPasswordForm" class="absolute inset-0 transform translate-x-full transition-transform duration-700 ease-in-out flex flex-col justify-between p-10 bg-white">
                <div class="title mb-6">
                    <h1 class="text-2xl font-bold">Forgot Password</h1>
                </div>
                <form id="forgotPasswordFormSubmit">
                    @csrf
                    <div class="space-y-5">
                        <div>
                            <label for="reset-email" class="block pb-3 text-sm font-medium text-gray-700">Email</label>
                            <input type="email" name="email" id="reset-email" class="focus:shadow-soft-primary-outline text-sm block w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-700" placeholder="example@polban.ac.id" required>
                        </div>
                    </div>
                    <div class="mt-6">
                        <button type="submit" class="inline-block w-full px-6 py-3 font-bold text-white uppercase bg-orange-500 hover:bg-orange-700 rounded-lg">
                            Kirim Kode Verifikasi
                        </button>
                    </div>
                </form>
                <form id="verificationCodeFormSubmit">
                    @csrf
                    <div class="space-y-5">
                        <div>
                            <label for="auth_code" class="block pb-3 text-sm font-medium text-gray-700">Kode Autentikasi</label>
                            <input type="text" name="auth_code" id="auth_code" class="border border-gray-300 rounded-lg w-full px-4 py-2" placeholder="123456" required>
                        </div>
                    </div>
                    <div class="mt-6">
                        <button type="submit" class="inline-block w-full px-6 py-3 font-bold text-white uppercase bg-orange-500 hover:bg-orange-700 rounded-lg">
                            Verifikasi Kode
                        </button>
                    </div>
                </form>
                <a href="#" id="backToLogin" class="text-blue-500"><strong>Back to Login</strong></a>
            </div>

            <!-- Reset Password Form -->
            <div id="resetPasswordForm" class="absolute inset-0 transform translate-x-full transition-transform duration-700 ease-in-out flex flex-col justify-between p-10 bg-white">
                <div class="title mb-6">
                    <h1 class="text-2xl font-bold">Reset Password</h1>
                </div>
                <form id="resetPasswordFormSubmit">
                    @csrf
                    <div class="space-y-5">
                        <div>
                            <label for="password1" class="block pb-3 text-sm font-medium text-gray-700">Password Baru</label>
                            <input type="password1" name="password1" id="password1" class="focus:shadow-soft-primary-outline text-sm block w-full rounded-lg border border-gray-300 px-3 py-2" required>
                        </div>
                        <div>
                            <label for="password_confirmation" class="block pb-3 text-sm font-medium text-gray-700">Konfirmasi Password</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="focus:shadow-soft-primary-outline text-sm block w-full rounded-lg border border-gray-300 px-3 py-2" required>
                            <p id="passwordError" style="color: red; font-size: 14px; display: none;"></p>
                        </div>
                    </div>
                    <div class="mt-6">
                        <button type="submit" class="inline-block w-full px-6 py-3 font-bold text-white uppercase bg-orange-500 hover:bg-orange-700 rounded-lg">
                            Reset Password
                        </button>
                    </div>
                </form>
            </div>

            <!-- Success Message -->
            <div id="resetSuccess" class="absolute inset-0 hidden flex flex-col justify-center items-center p-10 text-center">
                <h1 class="text-2xl font-bold mb-4">Password Changed Successfully</h1>
                <p class="text-lg text-gray-700 mb-8">Your password has been successfully updated!</p>
                <a href="#" id="backToLoginAfterSuccess" class="text-blue-500"><strong>Back to Login</strong></a>
            </div>
        </div>
    </section>
</main>

@if (session('error'))
    <script>
        Swal.fire({
            position: "center",
            title: "Terjadi Kesalahan!",
            text: "{{ session('error') }}",  // Menampilkan pesan error dari session
            showConfirmButton: false,
            timer: 1000,
            icon: "error"
        });
    </script>
@endif

<script>
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');
    const backToLogin = document.getElementById('backToLogin');
    const loginForm = document.getElementById('loginForm');
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    const resetPasswordForm = document.getElementById('resetPasswordForm');
    const resetSuccess = document.getElementById('resetSuccess');
    const backToLoginAfterSuccess = document.getElementById('backToLoginAfterSuccess');
    const errorText = document.getElementById('passwordError');

    // Reset error text
    errorText.textContent = '';
    errorText.style.display = 'none';

    // Transition to Forgot Password Form
    forgotPasswordLink.addEventListener('click', function (event) {
        event.preventDefault();
        forgotPasswordForm.classList.remove('hidden');
        setTimeout(() => {
            loginForm.classList.add('translate-x-full');
            forgotPasswordForm.classList.remove('translate-x-full');
        }, 50);
    });

    backToLogin.addEventListener('click', function (event) {
        event.preventDefault();
        forgotPasswordForm.classList.add('hidden');
        loginForm.classList.remove('translate-x-full');
    });

    // Handle Forgot Password Form Submission
    document.getElementById('forgotPasswordFormSubmit').addEventListener('submit', function(event) {
        event.preventDefault();
        const email = document.getElementById('reset-email').value;

        fetch('{{ route('password.forgot') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({ email })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Code sent!') {  // Menambahkan kode pengiriman sebagai respon
                // Jika berhasil, tampilkan form untuk verifikasi kode
                forgotPasswordForm.classList.remove('hidden');
                Swal.fire({
                    title: 'Success!',
                    text: data.message,
                    icon: 'success',
                    timer: 1000,
                    showConfirmButton: false
                });
            } else {
                Swal.fire({
                    title: 'Oops!',
                    text: 'Terjadi kesalahan: ' + data.message,
                    icon: 'error',
                    timer: 1000,
                    showConfirmButton: false
                });
            }
        })
        .catch(error => console.error('Error:', error));
    });

    // Formulir Verification Code
    document.getElementById('verificationCodeFormSubmit').addEventListener('submit', function(event) {
        event.preventDefault();
        const authCode = document.getElementById('auth_code').value;

        fetch('{{ route('password.verifyCode') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({ auth_code: authCode })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Verified!') {
                // Jika kode autentikasi valid, tampilkan form reset password
                forgotPasswordForm.classList.add('hidden');  // Sembunyikan form forgot password
                resetPasswordForm.classList.remove('hidden');  // Tampilkan form reset password

                // Tambahkan kelas untuk animasi atau transisi, jika perlu
                resetPasswordForm.classList.remove('translate-x-full');  // Pastikan form muncul dengan benar
                resetPasswordForm.classList.add('translate-x-0');
            } else {
                alert(data.message);  // Tampilkan pesan kesalahan jika kode tidak valid
            }
        })
        .catch(error => console.error('Error:', error));
    });

    // Formulir Reset Password
    document.getElementById('resetPasswordFormSubmit').addEventListener('submit', function(event) {
        event.preventDefault();

        const password = document.getElementById('password1').value;
        const passwordConfirmation = document.getElementById('password_confirmation').value;

        if (password !== passwordConfirmation) {
            errorText.textContent = 'Password dan konfirmasi password tidak sesuai.';
            errorText.style.display = 'block';
            return;
        }

        if (password.length < 8) {
            errorText.textContent = 'Password harus minimal 8 karakter.';
            errorText.style.display = 'block';
            return;
        }

        fetch('{{ route('password.update') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json', // Paksa Laravel merespons JSON
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({
                password: password,
                password_confirmation: passwordConfirmation
            })
        })
        .then(response => {
            return response.json().catch(() => {
                return response.text().then(text => {
                    console.error('Response not JSON:', text); // Menampilkan teks HTML error jika ada
                    throw new Error('Server response was not in JSON format');
                });
            });
        })
        .then(data => {
            if (data.message) {
                resetPasswordForm.classList.add('hidden');
                resetSuccess.classList.remove('hidden');
            } else {
                alert(data.error || 'Terjadi kesalahan, silakan coba lagi.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Terjadi kesalahan saat reset password.');
        });
    });

    // Back to Login from Success
    backToLoginAfterSuccess.addEventListener('click', function (event) {
        event.preventDefault();
        resetSuccess.classList.add('hidden');
        loginForm.classList.remove('translate-x-full');
    });
</script>

@endsection